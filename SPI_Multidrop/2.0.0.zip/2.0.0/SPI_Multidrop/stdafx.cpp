// stdafx.cpp : Quelldatei, die nur die Standard-Includes einbindet.
// SPI.pch ist der vorkompilierte Header.
// stdafx.obj enth�lt die vorkompilierten Typinformationen.

#include "stdafx.h"




// TODO: Auf zus�tzliche Header verweisen, die in STDAFX.H
// und nicht in dieser Datei erforderlich sind.
